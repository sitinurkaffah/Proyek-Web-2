var username = document.getElementById("username").value; 
var password = document.getElementById("password").value;
function login() {
    if (username == "admin" && password == "admin") {
        document.getElementById("loginpg").submit();
        location.href = "dashboard.html";
        console.log = "wxyz";
    }
    else {
        return false;
    }
}


